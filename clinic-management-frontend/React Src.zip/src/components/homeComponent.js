import {React} from 'react';
// import './CSS-Components/homeComponent.css;'

const Homecomponent = () => {
    return(
        <div>
            <h1>
            Welcome to ToothFixers Clinic Management!
            </h1>
            <h3>
            Where Smiles Come to Shine!
            </h3>
            <footer>C 2024. ToothFixers. All Rights Reserved</footer>
        </div>

    )
}

export default Homecomponent;